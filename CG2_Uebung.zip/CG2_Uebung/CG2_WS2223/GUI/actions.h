#ifndef ACTIONS_H
#define ACTIONS_H


class actions
{
public:
    actions();
};

#endif // ACTIONS_H
