#ifndef TABS_H
#define TABS_H

#include <QPushButton>
#include <QSpinBox>
#include <QVBoxLayout>
#include <qslider.h>



namespace cg2 {
}

#endif // TABS_H
