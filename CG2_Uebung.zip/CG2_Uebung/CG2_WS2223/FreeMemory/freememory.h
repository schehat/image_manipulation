#ifndef FREEMEMORY_H
#define FREEMEMORY_H

#include "Examples/examples2.h"


namespace cg2{
    void freeMemory();
}
#endif // FREEMEMORY_H
