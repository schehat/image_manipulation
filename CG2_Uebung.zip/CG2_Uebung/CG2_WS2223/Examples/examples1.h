#ifndef EXAMPLES1_H
#define EXAMPLES1_H

#include <qimage.h>

namespace cg2{
    QImage* exampleAlgorithm(QImage * image, int brightness_adjust_factor);
}

#endif // EXAMPLES1_H
