#ifndef EXAMPLES2_H
#define EXAMPLES2_H

#include <qimage.h>



namespace cg2{
    // Global image variable
    inline QImage* workingImage;
    QImage* drawRedCrossAlgorithm(int scale_factor);
}

#endif // EXAMPLES2_H
