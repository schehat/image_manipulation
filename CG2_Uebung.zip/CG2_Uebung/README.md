# CG2-Vorlage Readme



### Person 1

Name:

Matrikelnummer:

------------------------

### Person 2

Name: 

Matrikelnummer:

---------------------





## Hinweis

- **Pictures** Ordner muss auf gleicher Ebene wie **CG2_WS2223** sein

